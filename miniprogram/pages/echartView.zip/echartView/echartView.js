// pages/echartView/echartView.js
import * as echarts from '../../ec-canvas/echarts';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ec:{
      lazyLoad:true,
    },
    // 这个是日期 
    x15data:['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
    // 这个是最大温度
    y15data1:[18, 36, 55, 30, 58,20],
    // 这个是最小温度
    y15data2:[10, 30, 31, 50, 40, 20]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.ecComponent = this.selectComponent('#mychart15')
    this.setData({

    },()=>{
      this.initCharts()
    })
  },
  initCharts:function(){
    this.ecComponent.init((canvas,width,height,dpr)=>{
      const chart = echarts.init(canvas,null,{
        width:width,
        height:height,
        devicePixelRatio:dpr
      })
      canvas.setChart(chart)
      var option = {
       
        
        grid:{
          top:0,
          left:0,
          right:0,
          bottom:0
        },
        xAxis:{
          type:'category',
          interval: 24 * 60 * 60 * 100,
          axisLine:{
            show:false,
            lineStyle:{
              color:'rgba(255,255,0,1)',
            },
          },
          data:this.data.x15data
        },
        yAxis:
          {
            type:'value',
            axisLine:{
              show:false,
              lineStyle:{
                color:'rgba(255,255,0,0)'
              },
            },
            axisLabel:{
              color:'rgba(255,255,0,0)'
            },
            splitLine:{
              lineStyle:{
                color:'rgba(255,255,0,0)'
              },
            }
          }
        ,
        series:[
          {
            name:'热度',
            type:'line',
            data:this.data.y15data1,
            symbol: 'circle',
            itemStyle : { 
              normal: {
                color: "#fda202",
                label : {
                  show: true
                },
                lineStyle:{
                  color:'#faea8e'
                }
              }
            },
            smooth:true
          },
          {
            name:'正面',
            type:'line',
            symbol: 'circle',
            data:this.data.y15data2,
            itemStyle : { normal: {color: "#4094e9",label : {show: true},lineStyle:{
              color:'#a3e2fc'
            }}},
            smooth:true
          },
        ]
      }
      chart.setOption(option)
      this.chart = chart;
      return chart;

    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})